<!DOCTYPE html>
<html>
<body style="background:#000080;margin:0px">
<div style="margin-left:1px; font:bold 14px verdana; color:#FFFF00;"><i>ChartDirector 7.0 Sample Programs</i></div>
</body>
</html>
